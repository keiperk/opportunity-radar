/*
 * Detail page logic. Company data, scoring formula, and shared helpers
 * live in data.js (loaded before this file).
 */

function getSelectedCompanyFromUrl() {
  const params = new URLSearchParams(window.location.search);
  const name = params.get('company');
  return (name && findCompany(name)) || findCompany('EdVisorly') || companies[0];
}

const c = getSelectedCompanyFromUrl();
const cls = tierClass(c.tier);

/* ── Header ── */
document.getElementById('detail-name').textContent = c.company;
document.title = `${c.company} — Company Detail`;

const tierBadge = document.getElementById('detail-tier-badge');
tierBadge.textContent = c.tier.toUpperCase();
tierBadge.className = 'tier-badge' + (cls ? ` tier-${cls}` : '');

const indexEl = document.getElementById('detail-index');
indexEl.textContent = c.opportunity_index.toFixed(2);
indexEl.style.color = cls === 'amber' ? 'var(--amber-deep)' : cls === 'rose' ? 'var(--rose-deep)' : 'var(--accent-deep)';

/* ── Signal Breakdown (stacked mini cards) ── */
const sourceDefs = [
  { label: 'News', value: c.news_signals },
  { label: 'Reddit', value: c.reddit_signals },
  { label: 'LinkedIn', value: c.linkedin_signals },
];
document.getElementById('breakdown-stack').innerHTML = sourceDefs.map((s) => `
  <div class="breakdown-mini-card">
    <div class="breakdown-mini-label">${s.label.toUpperCase()}</div>
    <div class="breakdown-mini-value">${s.value}</div>
    <div class="meter-track"><div class="meter-fill ${cls}" style="width:${Math.min(100, (s.value / CAP) * 100).toFixed(0)}%"></div></div>
    <p class="breakdown-mini-caption">of ${CAP} tracked</p>
  </div>
`).join('');

/* ── How This Is Calculated ── */
const mathDefs = [
  { label: 'News', value: c.news_signals, weight: WEIGHTS.news },
  { label: 'Reddit', value: c.reddit_signals, weight: WEIGHTS.reddit },
  { label: 'LinkedIn', value: c.linkedin_signals, weight: WEIGHTS.linkedin },
];
let total = 0;
document.getElementById('detail-math-rows').innerHTML = mathDefs.map((d) => {
  const norm = Math.min(d.value, CAP) / CAP;
  const contribution = norm * d.weight;
  total += contribution;
  return `<div class="math-row"><span class="math-label">${d.label}  ${d.value}/${CAP}</span><span class="math-detail">${norm.toFixed(2)} × ${(d.weight * 100).toFixed(0)}% = ${contribution.toFixed(3)}</span></div>`;
}).join('');
document.getElementById('detail-math-total').textContent = (Math.round(total * 100) / 100).toFixed(2);

/* ── Momentum Trend chart (SVG) ── */
function renderTrendChart() {
  const history = generateTrendHistory(c.opportunity_index_precise);
  const W = 560, H = 140, PAD = 8;
  const min = Math.min(...history), max = Math.max(...history);
  const range = Math.max(max - min, 0.001);
  const usable = H - PAD * 2;
  const pts = history.map((v, i) => ({
    x: (i * W) / (history.length - 1),
    y: PAD + usable - ((v - min) / range) * usable,
  }));

  const areaCmds = `M ${pts[0].x.toFixed(1)} ${H} ` + pts.map((p) => `L ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ') + ` L ${pts[pts.length - 1].x.toFixed(1)} ${H} Z`;
  const lineCmds = pts.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
  const dotsSvg = pts.map((p) => `<circle cx="${p.x.toFixed(1)}" cy="${p.y.toFixed(1)}" r="3" fill="#ffffff" stroke="${THEME.accent}" stroke-width="2" />`).join('');

  document.getElementById('trend-svg').innerHTML = `
    <path d="${areaCmds}" fill="${THEME.accent}" opacity="0.14" />
    <path d="${lineCmds}" fill="none" stroke="${THEME.accent}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
    ${dotsSvg}
  `;
}
renderTrendChart();

/* ── Why This Matters ── */
document.getElementById('detail-why-text').textContent = generateWhyItMatters(c);

/* ── Suggested Contact ── */
const emailHandle = c.company.toLowerCase().replace(/[^a-z0-9]+/g, '');
document.getElementById('detail-contact-title').textContent = `Engineering Recruiter · ${c.company}`;
document.getElementById('detail-contact-email').textContent = `jordan.reyes@${emailHandle}.com`;
