/*
 * Shared data + scoring logic for the Opportunity Radar dashboard and
 * detail page. Real data from the Opportunity Radar v2 pipeline's
 * `radar_results` export (run_id 384). Formula reverse-engineered from the
 * CSV and confirmed to match exactly: weights news 0.35 / reddit 0.30 /
 * linkedin 0.35, each source capped at 40 before normalizing. No live
 * workflow connection — this is a static snapshot of one real run.
 */
const CAP = 40;
const WEIGHTS = { news: 0.35, reddit: 0.30, linkedin: 0.35 };

/*
 * Single source of truth for the accent color, shared by styles.css (via
 * the matching --accent custom properties — keep these in sync manually,
 * since CSS custom properties aren't readable from raw SVG string
 * templates) and the JS-rendered SVG (radar, trend chart) in app.js /
 * detail.js. Change the color here and in styles.css :root together.
 */
const THEME = {
  accent: '#607d8b',     // Material Blue Grey 500 — matches --accent
  accentDeep: '#455a64', // Material Blue Grey 700 — matches --accent-deep
  accentTint: '#eceff1', // Material Blue Grey 50  — matches --accent-tint
  dark: '#0e1015',
  amber: '#f59e0b',
  rose: '#f87171',
  border: '#e0e1e4', // matches --border, used for gauge track
};

const runMeta = {
  run_id: '384',
  run_ts: '2026-07-12T21:26:29Z',
  workflow_status: 'success',
};

const rawCompanies = [
  { company: 'Surge AI', news: 30, reddit: 39, linkedin: 40 },
  { company: 'Merge Labs', news: 36, reddit: 40, linkedin: 40 },
  { company: 'Inferact', news: 37, reddit: 40, linkedin: 40 },
  { company: 'Radical Ventures', news: 29, reddit: 29, linkedin: 30 },
  { company: 'Monogram', news: 28, reddit: 30, linkedin: 30 },
  { company: 'a1mobile', news: 40, reddit: 38, linkedin: 40 },
  { company: 'Together AI', news: 39, reddit: 40, linkedin: 40 },
  { company: 'EdVisorly', news: 40, reddit: 39, linkedin: 40 },
  { company: 'Featherless.ai', news: 36, reddit: 40, linkedin: 40 },
  { company: 'Rhoda AI', news: 36, reddit: 39, linkedin: 40 },
  { company: 'Slidebean', news: 30, reddit: 30, linkedin: 30 },
];

function computeIndex(news, reddit, linkedin) {
  const n = Math.min(news, CAP) / CAP;
  const r = Math.min(reddit, CAP) / CAP;
  const l = Math.min(linkedin, CAP) / CAP;
  return n * WEIGHTS.news + r * WEIGHTS.reddit + l * WEIGHTS.linkedin;
}

function tierOf(idx) {
  if (idx >= 0.8) return 'Very Strong';
  if (idx >= 0.6) return 'Strong';
  if (idx >= 0.4) return 'Moderate';
  if (idx >= 0.2) return 'Weak';
  return 'Very Weak';
}

function tierClass(tier) {
  if (tier === 'Very Strong' || tier === 'Strong') return '';
  if (tier === 'Moderate') return 'amber';
  return 'rose';
}

const companies = rawCompanies.map((c) => {
  const index = computeIndex(c.news, c.reddit, c.linkedin);
  const tier = tierOf(index);
  return {
    company: c.company,
    news_signals: c.news,
    reddit_signals: c.reddit,
    linkedin_signals: c.linkedin,
    opportunity_index: Math.round(index * 100) / 100,
    opportunity_index_precise: index,
    tier,
  };
});

function findCompany(name) {
  return companies.find((c) => c.company === name) || null;
}

function generateWhyItMatters(c) {
  const sources = [
    { label: 'News', value: c.news_signals },
    { label: 'Reddit', value: c.reddit_signals },
    { label: 'LinkedIn', value: c.linkedin_signals },
  ];
  const top = sources.reduce((a, b) => (b.value > a.value ? b : a));
  const tierPhrase = c.tier.toLowerCase();
  const growthPhrase = c.tier === 'Very Strong' || c.tier === 'Strong'
    ? 'active headcount growth rather than a single one-off signal spike, making it a reasonable near-term target for outreach'
    : 'some hiring-adjacent activity, though the signal is not yet strong enough to be a confident outreach priority';
  return `${c.company} is showing ${tierPhrase} combined signal this scan — driven primarily by ${top.label.toLowerCase()} activity (${top.value} mentions), alongside its news and Reddit presence. That combination usually means ${growthPhrase}.`;
}

/*
 * Illustrative trend history leading to each company's real, current
 * index — only the final point reflects a real pipeline run. Deterministic
 * (same shape every load), not randomized.
 */
function generateTrendHistory(finalValue) {
  return [finalValue * 0.70, finalValue * 0.82, finalValue * 0.91, finalValue];
}

function hexToRgba(hex, alpha) {
  const n = parseInt(hex.replace('#', ''), 16);
  const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function escapeXml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}
