/*
 * Dashboard page logic. Company data, scoring formula, and shared helpers
 * live in data.js (loaded before this file).
 */

/* ── DOM refs ── */
const searchInput = document.getElementById('search-input');
const sortToggle = document.getElementById('sort-toggle');
const groupToggle = document.getElementById('group-toggle');
const clearButton = document.getElementById('clear-filters');
const rankedListEl = document.getElementById('ranked-list');
const listEmptyEl = document.getElementById('list-empty');
const companiesTrackedCountEl = document.getElementById('companies-tracked-count');
const radarSvg = document.getElementById('radar-svg');
const viewReportBtn = document.getElementById('view-report-btn');

let sortDirection = 'desc';
let groupByTier = true;
let selectedCompany = findCompany('EdVisorly') || companies[0];

/* ── Radar (SVG) ── */
function renderRadar() {
  const CX = 200, CY = 200, MIN_R = 25, MAX_R = 175;
  const ringColor = hexToRgba(THEME.accent, 0.25);
  let svg = '';

  [50, 94, 138, 181].forEach((r) => {
    svg += `<circle cx="${CX}" cy="${CY}" r="${r}" fill="none" stroke="${ringColor}" stroke-width="1" />`;
  });
  svg += `<line x1="20" y1="${CY}" x2="380" y2="${CY}" stroke="${ringColor}" stroke-width="1" />`;
  svg += `<line x1="${CX}" y1="20" x2="${CX}" y2="380" stroke="${ringColor}" stroke-width="1" />`;
  svg += `<circle cx="${CX}" cy="${CY}" r="3" fill="${THEME.dark}" />`;

  companies.forEach((c, i) => {
    const angleDeg = -90 + i * (360 / companies.length);
    const angleRad = (angleDeg * Math.PI) / 180;
    const radius = MIN_R + (1 - c.opportunity_index) * (MAX_R - MIN_R);
    const cosV = Math.cos(angleRad), sinV = Math.sin(angleRad);
    const px = CX + radius * cosV, py = CY + radius * sinV;
    const diameter = 6 + c.opportunity_index * 12;
    const opacity = 0.55 + c.opportunity_index * 0.45;
    const isSelected = c.company === selectedCompany.company;
    const color = tierClass(c.tier) === 'amber' ? THEME.amber : tierClass(c.tier) === 'rose' ? THEME.rose : THEME.accent;

    if (isSelected) {
      const ringD = diameter + 8;
      svg += `<circle cx="${px}" cy="${py}" r="${ringD / 2}" fill="none" stroke="${THEME.dark}" stroke-width="1.5" stroke-dasharray="3 2" />`;
    }
    svg += `<circle class="radar-blip" data-company="${c.company}" cx="${px}" cy="${py}" r="${diameter / 2}" fill="${color}" opacity="${opacity}" style="cursor:pointer" />`;

    let labelX = px, labelY = py, anchor = 'middle';
    if (cosV > 0.3) { labelX = px + diameter / 2 + 4; anchor = 'start'; }
    else if (cosV < -0.3) { labelX = px - diameter / 2 - 4; anchor = 'end'; }
    if (sinV < -0.3) labelY = py - diameter / 2 - 4;
    else if (sinV > 0.3) labelY = py + diameter / 2 + 9;

    svg += `<text data-company="${c.company}" x="${labelX}" y="${labelY}" text-anchor="${anchor}" font-size="6.5" font-family="Inter, sans-serif" fill="${THEME.dark}" style="cursor:pointer">${escapeXml(c.company)}</text>`;
  });

  radarSvg.innerHTML = svg;
  radarSvg.querySelectorAll('[data-company]').forEach((el) => {
    el.addEventListener('click', () => selectCompany(el.getAttribute('data-company')));
  });
}

/* ── Ranked list ── */
function renderList() {
  const query = searchInput.value.trim().toLowerCase();
  const filtered = companies.filter((c) => !query || c.company.toLowerCase().includes(query));
  const sorted = filtered.slice().sort((a, b) =>
    sortDirection === 'desc' ? b.opportunity_index_precise - a.opportunity_index_precise : a.opportunity_index_precise - b.opportunity_index_precise
  );

  rankedListEl.innerHTML = '';
  listEmptyEl.hidden = sorted.length !== 0;
  companiesTrackedCountEl.textContent = `${companies.length} companies tracked`;

  function renderRow(c) {
    const cls = tierClass(c.tier);
    const row = document.createElement('div');
    row.className = 'company-row' + (c.company === selectedCompany.company ? ' selected' : '');
    row.dataset.company = c.company;

    row.innerHTML = `
      <div class="company-row-top">
        <a class="company-row-name" href="detail.html?company=${encodeURIComponent(c.company)}">${escapeXml(c.company)}</a>
        <span class="company-row-index ${cls}">${c.opportunity_index.toFixed(2)}</span>
      </div>
      <div class="company-row-sources">
        <span class="source-pill">News ${c.news_signals}</span>
        <span class="source-pill">Reddit ${c.reddit_signals}</span>
        <span class="source-pill">LinkedIn ${c.linkedin_signals}</span>
      </div>
      <div class="meter-track"><div class="meter-fill ${cls}" style="width:${(c.opportunity_index * 100).toFixed(0)}%"></div></div>
    `;
    row.addEventListener('click', () => selectCompany(c.company));
    row.querySelector('.company-row-name').addEventListener('click', (e) => e.stopPropagation());
    return row;
  }

  if (!groupByTier) {
    sorted.forEach((c) => rankedListEl.appendChild(renderRow(c)));
    return;
  }

  const groupOrder = ['Very Strong', 'Strong', 'Moderate', 'Weak', 'Very Weak'];
  groupOrder.forEach((tierName) => {
    const members = sorted.filter((c) => c.tier === tierName);
    if (members.length === 0) return;
    const cls = tierClass(tierName);

    const group = document.createElement('div');
    group.className = 'tier-group';
    const header = document.createElement('div');
    header.className = 'tier-group-header';
    header.innerHTML = `<span class="tier-group-dot ${cls}"></span><span class="tier-group-label ${cls}">${tierName.toUpperCase()} — ${members.length}</span>`;
    group.appendChild(header);
    members.forEach((c) => group.appendChild(renderRow(c)));
    rankedListEl.appendChild(group);
  });
}

/* ── Job Opportunity Signals: radial gauge ── */
function renderRolesGauge(value, max, cls) {
  const gaugeSvg = document.getElementById('roles-gauge');
  const size = 100, stroke = 10, r = (size - stroke) / 2, cx = size / 2, cy = size / 2;
  const circumference = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(1, value / max));
  const dash = circumference * pct;
  const color = cls === 'amber' ? THEME.amber : cls === 'rose' ? THEME.rose : THEME.accent;

  gaugeSvg.innerHTML = `
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${THEME.border}" stroke-width="${stroke}" />
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
      stroke-linecap="round" stroke-dasharray="${dash.toFixed(2)} ${circumference.toFixed(2)}" />
  `;
}

/* ── Right rail: Inspector / Job Signals / Contact ── */
function renderInspector() {
  const c = selectedCompany;
  const cls = tierClass(c.tier);

  document.getElementById('inspector-name').textContent = c.company;
  const badge = document.getElementById('inspector-tier-badge');
  badge.textContent = c.tier.toUpperCase();
  badge.className = 'tier-badge' + (cls ? ` tier-${cls}` : '');
  document.getElementById('inspector-index').textContent = c.opportunity_index.toFixed(2);
  document.getElementById('inspector-index').style.color = cls === 'amber' ? 'var(--amber-deep)' : cls === 'rose' ? 'var(--rose-deep)' : 'var(--accent-deep)';

  const sourceDefs = [
    { label: 'News', value: c.news_signals },
    { label: 'Reddit', value: c.reddit_signals },
    { label: 'LinkedIn', value: c.linkedin_signals },
  ];
  const breakdownEl = document.getElementById('signal-breakdown');
  breakdownEl.innerHTML = sourceDefs.map((s) => `
    <div class="mini-breakdown-row">
      <div class="mini-breakdown-top"><span class="label">${s.label}</span><span class="value">${s.value}</span></div>
      <div class="meter-track"><div class="meter-fill ${cls}" style="width:${Math.min(100, (s.value / CAP) * 100).toFixed(0)}%"></div></div>
    </div>
  `).join('');

  const top = sourceDefs.reduce((a, b) => (b.value > a.value ? b : a));
  document.getElementById('strongest-signal-text').textContent = `${top.label} — ${top.value} mentions this scan`;

  const mathDefs = [
    { label: 'News', value: c.news_signals, weight: WEIGHTS.news },
    { label: 'Reddit', value: c.reddit_signals, weight: WEIGHTS.reddit },
    { label: 'LinkedIn', value: c.linkedin_signals, weight: WEIGHTS.linkedin },
  ];
  let total = 0;
  const rowsHtml = mathDefs.map((d) => {
    const norm = Math.min(d.value, CAP) / CAP;
    const contribution = norm * d.weight;
    total += contribution;
    return `<div class="math-row"><span class="math-label">${d.label}  ${d.value}/${CAP}</span><span class="math-detail">${norm.toFixed(2)} × ${(d.weight * 100).toFixed(0)}% = ${contribution.toFixed(3)}</span></div>`;
  }).join('');
  document.getElementById('math-rows').innerHTML = rowsHtml;
  document.getElementById('math-total-value').textContent = (Math.round(total * 100) / 100).toFixed(2);

  renderRolesGauge(c.linkedin_signals, CAP, tierClass(c.tier));
  document.getElementById('open-roles-value').textContent = c.linkedin_signals;
  const momentumBadge = document.getElementById('hiring-momentum-badge');
  const momentumLabel = c.tier === 'Very Strong' || c.tier === 'Strong' ? 'Actively Growing' : c.tier === 'Moderate' ? 'Steady' : 'Quiet';
  momentumBadge.textContent = momentumLabel;
  momentumBadge.className = 'tier-badge' + (cls ? ` tier-${cls}` : '');
  document.getElementById('why-it-matters-text').textContent = generateWhyItMatters(c);

  const emailHandle = c.company.toLowerCase().replace(/[^a-z0-9]+/g, '');
  document.getElementById('contact-title').textContent = `Engineering Recruiter · ${c.company}`;
  document.getElementById('contact-email').textContent = `jordan.reyes@${emailHandle}.com`;

  if (viewReportBtn) viewReportBtn.href = `detail.html?company=${encodeURIComponent(c.company)}`;
}

function selectCompany(companyName) {
  const found = findCompany(companyName);
  if (!found) return;
  selectedCompany = found;
  renderRadar();
  renderList();
  renderInspector();
}

/* ── Filter/sort/group controls ── */
searchInput.addEventListener('input', renderList);

sortToggle.addEventListener('click', () => {
  sortDirection = sortDirection === 'desc' ? 'asc' : 'desc';
  sortToggle.classList.toggle('sort-asc', sortDirection === 'asc');
  renderList();
});

groupToggle.addEventListener('click', () => {
  groupByTier = !groupByTier;
  groupToggle.setAttribute('aria-pressed', String(groupByTier));
  renderList();
});

clearButton.addEventListener('click', () => {
  searchInput.value = '';
  sortDirection = 'desc';
  groupByTier = true;
  sortToggle.classList.remove('sort-asc');
  groupToggle.setAttribute('aria-pressed', 'true');
  renderList();
});

/* ── Init ── */
renderRadar();
renderList();
renderInspector();
